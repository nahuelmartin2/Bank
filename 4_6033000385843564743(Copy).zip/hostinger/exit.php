<?php

header("https://www.hostinger.com/");

?>